﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Validación_de_Usuario01
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }
   

        //Para arrastrar la interfaz

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);



        //FOLIO USUARIO
        public static string[] folioUsuario = new string[11]; //arreglo para niveles "A"  y  "U"



        // NIVEL DE USUARIO

        public static  string[] nivelUsuario = new string[11]; //arreglo para niveles "A"  y  "U" DE AMDMINISTRADOR O USUARIO



        //Ahora es el metodo del IDUSUARIO

        
       public static string[] idUsuarios = new string[11]; //Construccion del arreglo unidimensional DEL ID
       public static int ValIDUsarios(string UsuarioID)
        {
            int casillaUsuario = 0;
            for(int i=0;i<10;i++)
                if(UsuarioID == idUsuarios[i])
                {

                    casillaUsuario = i;
                    break;
                }
            return casillaUsuario;
        }


        ////metodo del USUARIO

        //string Usuario = "admin";

        //int ingresar = 0;
        public static string[] accesoUsuarios = new string[11]; //Construccion del arreglo unidimensional del USUARIO
        public static int validacionUsarios(string nombreUsuario)
        {
            int casillaUsuario = 0;
            for (int i = 0; i < 10; i++)
                if (nombreUsuario == accesoUsuarios[i])
                {

                    casillaUsuario = i;
                    break;
                }
            return casillaUsuario;
        }

        //Metdo de LA CONTRASEÑA

        public static   string[] contraUsuarios = new string[11]; //Construccion del arreglo uni de la CONTRASEÑA

        bool validacionContra(int casillaUsuario, string paswordUsuario)
        {

            bool contraValidado = false;

            if (paswordUsuario == contraUsuarios[casillaUsuario] )
        
            {



                contraValidado = true;
                

            }
          
            return contraValidado;
            
        }
        
        //SE CREO EL METODO DE NIVEL USUARIO de NIVEL

      string infoNivel(int indiceUsuario)
        {
            string TipoNivel = null;

            TipoNivel = nivelUsuario[indiceUsuario];

            return TipoNivel;
        }

     

        //Random rdn = new Random();
        //string generaFolio()
        //{
        //    string folio = null;

        //    for (int i = 0; i < 6; i++)
        //    {
        //        int x = rdn.Next(0, 9);
        //        folio = folio + x.ToString();
        //    }

        //    return folio;
        //}

        private void Form1_Load(object sender, EventArgs e)
        {
            //USUARIOS

            accesoUsuarios[0] = "Admin";
            accesoUsuarios[1] = "Isai";
            accesoUsuarios[2] = "Fernando";
            accesoUsuarios[3] = "Berenice";
            accesoUsuarios[4] = "Peter";
            accesoUsuarios[5] = "Luis";


            //CONTRASEÑA DE USUARIOS

            contraUsuarios[0] = "pass";
            contraUsuarios[1] = "mac";
            contraUsuarios[2] = "windows";
            contraUsuarios[3] = "123";
            contraUsuarios[4] = "12teams";
            contraUsuarios[5] = "12teams";
         

            //NIVEL DE USUARIO

            nivelUsuario[0] = "A";
            nivelUsuario[1] = "U";
            nivelUsuario[2] = "A";
            nivelUsuario[3] = "U";
            nivelUsuario[4] = "U";
            nivelUsuario[5] = "A";

            //ID USUARIOS idUsuarios[0] = "12345";
          
        }



        
        //Boton de ACCEDER 
        private void button1_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("" + validacionContra (validacionUsarios(textBox1.Text),textBox2.Text));
            //validar el accceso solo si el nivel es de Administrador

            
            if (validacionContra(ValIDUsarios(textBox1.Text), textBox2.Text))

                if (nivelUsuario [ValIDUsarios(textBox1.Text)]=="A") { 
                Form2 form2 = new Form2();
                form2.textBox1.Text = textBox1.Text;

                form2.textBox2.Text = infoNivel(ValIDUsarios(textBox1.Text));

                form2.Show();
            }
            else
            {
                MessageBox.Show("No cuenta con los permisos necesarios");

        
            }

            else
            {
                MessageBox.Show("El usuario no Existe", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            textBox1.Clear();
            textBox2.Clear();
         
        }

        //Boton de Cerrar
        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Regrese Pronto");
            Application.Exit();
        }

        //Boton de registrar
        private void button3_Click(object sender, EventArgs e)
        {
            Hide();
            Form3 form3 = new Form3();
            form3.Show();
        }

        //Boton de cerrar APP
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Mover la interfaz
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        //LLaves de cierre
    }
}
