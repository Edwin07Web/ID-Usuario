﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Validación_de_Usuario01
{
    public partial class EliminaUsuario : Form
    {

        //Metodo buscarVacio

        public static int buscarVacio()
        {
            int indice = 0;
            for (int i = 1; 1 < 11; i++)
            {
                if (Form1.accesoUsuarios[i] == null)
                {
                    indice = i;
                    break;

                }
            }
            return indice;
        }



        //metodo de elimnar usuario, null= vacio

        bool metodoEliminar(int casillaEliminar)
        {
            bool errorCasilla = false;
            if (casillaEliminar != 0)
            { 
                Form1.accesoUsuarios[casillaEliminar] = null;
                Form1.contraUsuarios[casillaEliminar] = null;
                Form1.nivelUsuario[casillaEliminar] = null;
                Form1.folioUsuario[casillaEliminar] = null;
                errorCasilla = true;
            }
            return errorCasilla;
        }
        public EliminaUsuario()
        {
            InitializeComponent();
        }

        //Boton aceptar para validar
        private void button1_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == MessageBox.Show("Desea Elimarlo ?", "Eliminar", MessageBoxButtons.OKCancel))
            {
                


                if (metodoEliminar(Form1.validacionUsarios(textBox1.Text)))
                {
                    MessageBox.Show("Usuario Eliminado");

                }
                else
                {
                    MessageBox.Show("El usuario no Existe", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        //Llaves de cierre
    }
}
