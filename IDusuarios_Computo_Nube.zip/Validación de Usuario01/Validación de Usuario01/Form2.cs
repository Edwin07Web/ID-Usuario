﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;


namespace Validación_de_Usuario01
{
    public partial class Form2 : Form
    {

        Random rdn = new Random();
        string generaFolio()
        {
            string folio = null;

            for (int i = 0; i < 6; i++)
            {
                int x = rdn.Next(0, 9);
                folio = folio + x.ToString();
            }

            return folio;
        }

        public Form2()
        {
            InitializeComponent();
        }

        //Para arrastrar la interfaz

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void Form2_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //usario
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        //text NIVEL
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }


        //Registrarse 
        private void button1_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Boton de eliminar Usuario
        private void button2_Click_1(object sender, EventArgs e)
        {
            EliminaUsuario elimina = new EliminaUsuario();
            elimina.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }

      

        //Nuevo Usuario
        private void button1_Click_1(object sender, EventArgs e)
        {
            

            for (int i = 0; i < 1; i++)
                
            {
                Form3 form3 = new Form3();
                
                form3.textBox5.Text = form3.textBox5.Text + generaFolio() + Form1.folioUsuario[i];
                form3.Show();
            }
             
           
        }

        //Mover la interfaz
        private void Form2_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
        //LLaves de cierre
    }
}
