﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;


namespace Validación_de_Usuario01
{
    public partial class Form3 : Form
    {

        public Form3()
        {
            InitializeComponent();
        }

        //Para arrastrar la interfaz

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);


        //Random rdn = new Random();
        //string generaFolio()
        //{
        //    string folio = null;

        //    for (int i = 0; i < 6; i++)
        //    {
        //        int x = rdn.Next(0, 9);
        //        folio = folio + x.ToString();
        //    }

        //    return folio;
        //}


        //PaRA QUE NO SE REPITA EL USUARIO

        bool encontrarFolio(string cadenaFolio)
        {
            bool encontrado = false;
            for (int i = 1; i < 11; i++)
            {
                if (Form1.folioUsuario[i] == cadenaFolio)
                {
                    encontrado = true;
                }
            }
            return encontrado;
        }

        //Proceso de almacenaje     

        void guardarRegistro(string UsuarioID,string nombreUsuario,string passUsuario,string nivelUsuario,int casillaAlmacenaje)
        {
            Form1.idUsuarios[casillaAlmacenaje] = UsuarioID;
            Form1.accesoUsuarios[casillaAlmacenaje] = nombreUsuario;
            Form1.contraUsuarios[casillaAlmacenaje] = passUsuario;
            Form1.nivelUsuario[casillaAlmacenaje] = nivelUsuario;
            //Form1.folioUsuario[casillaAlmacenaje] = folio;
            //Form1.IDUsuario[casillaAlmacenaje] = folio;
        }
   
        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        //BOTON DE GUARDAR DATOS 
        private void button1_Click(object sender, EventArgs e)
        {
           
            if (textBox2.Text == textBox4.Text)
            {

                guardarRegistro(textBox5.Text, textBox1.Text,textBox2.Text, comboBox1.Text,EliminaUsuario.buscarVacio());
                MessageBox.Show("Se guardo exitosamente el Usuario");
                
            }
            else
            {
                MessageBox.Show("La contraseña no coincide");
                textBox2.Clear();
                textBox4.Clear();
            }
        }

        
        
        private void Form3_Load(object sender, EventArgs e)
        {
            
        }

     

        //BOTON DE X CERRAR APLICACION
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /*Boton Mostrar FOLIO
        private void button3_Click_1(object sender, EventArgs e)
        {
          
            //for (int i = 0; i < 11; i++)
            //{
            //    textBox5.Text = textBox5.Text + "  " + Form1.folioUsuario[i];
               
            //}
            
        }*/

        //boton de cerrar ventana
        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        //Mover la interfaz
        private void Form3_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        //llaves de cierre
    }
}
